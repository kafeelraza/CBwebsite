async function getsongs(params) {
    let a=await fetch("http://127.0.0.1:3000/songs/")
    let response=await a.text();
    let div=document.createElement("div")
    div.innerHTML=response;
    let as=div.getElementsByTagName("a");
    let songs=[];
    for(let i=0;i<as.length;i++){
        const element=as[i];
        if(element.href.endsWith(".mp3")){
            songs.push(element.href)
        }
    }
    return songs
}
async function main(params) {
    
    let songs= await getsongs()
    console.log(songs)
}
main()
const playmusic=(track)=>{
    // let audio=new Audio("/songs/"+track)
    currentsong.src="/songs/"+track
    currentsong.play();
    play.src="pause.svg"
}
async function main(params) {
 
    let songs= await getsongs()
    console.log(songs)
    let songul=document.querySelector(".songlist").getElementsByTagName("ul")[0];
    for(const song of songs){
        songul.innerHTML=songul.innerHTML+`<li> 
       
                        <img class="invert" width="34" src="music.svg" alt="">
                        <div class="info">
                            <div>${song.replaceAll("%20"," ").replace(".mp3","")}</div>
                            <div>song artist</div>
                        </div>
                        <div class="playnow">
                           <span>play now</span>
                            <img class="invert" src="play.svg" alt="">
                        </div>
                    
        
        
        
        </li>`;

    }
    Array.from(document.querySelector(".songlist").getElementsByTagName("li")).forEach(e => {
        e.addEventListener("click",element=>{

            console.log(e.querySelector(".info").firstChild.innerHTML);        
        playmusic(e.querySelector(".info").firstChild.innerHTML.trim());
        })
    })
    



    play.addEventListener("click",()=>{
        if(currentsong.paused){
            currentsong.play();
            play.src="pause.svg"
               }
else{
    currentsong.pause();
    play.src="play.svg"
}
    })
}
main() 